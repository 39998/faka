<?php
declare (strict_types=1);

return [
    'version' => '1.2.5',
];