<?php
declare (strict_types=1);

namespace Kernel\Exception;


class JSONException extends \Exception
{

}