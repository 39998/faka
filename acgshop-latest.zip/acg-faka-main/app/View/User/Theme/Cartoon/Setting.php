<?php
declare (strict_types=1);

return [
    'style' => '2',
    'icp' => '',
    'cache' => '0',
    'cache_expire' => '60',
];