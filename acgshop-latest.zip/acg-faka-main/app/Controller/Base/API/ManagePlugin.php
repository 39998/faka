<?php
declare(strict_types=1);

namespace App\Controller\Base\API;


abstract class ManagePlugin extends Manage
{

}